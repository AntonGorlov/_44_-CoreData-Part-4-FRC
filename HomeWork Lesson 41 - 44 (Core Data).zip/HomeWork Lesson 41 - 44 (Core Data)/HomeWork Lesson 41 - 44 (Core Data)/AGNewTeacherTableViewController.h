//
//  AGNewTeacherTableViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 18.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AGTeacher;
@interface AGNewTeacherTableViewController : UITableViewController


@property (strong, nonatomic) AGTeacher *teacher;

@end
