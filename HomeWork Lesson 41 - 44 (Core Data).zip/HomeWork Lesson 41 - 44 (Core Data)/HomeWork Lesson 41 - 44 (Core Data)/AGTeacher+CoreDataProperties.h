//
//  AGTeacher+CoreDataProperties.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 16.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGTeacher.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGTeacher (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *firstName;
@property (nullable, nonatomic, retain) NSString *lastName;
@property (nullable, nonatomic, retain) NSSet<AGCourse *> *course;

@end

@interface AGTeacher (CoreDataGeneratedAccessors)

- (void)addCourseObject:(AGCourse *)value;
- (void)removeCourseObject:(AGCourse *)value;
- (void)addCourse:(NSSet<AGCourse *> *)values;
- (void)removeCourse:(NSSet<AGCourse *> *)values;

@end

NS_ASSUME_NONNULL_END
