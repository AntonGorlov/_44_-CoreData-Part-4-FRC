//
//  AGUsersViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 06.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCoreDataViewController.h"


@interface AGUsersViewController : AGCoreDataViewController


@end
