//
//  AGNewCourseTableViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 08.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AGAddCoreCell.h"

@class AGCourse;
@interface AGNewCourseTableViewController : UITableViewController 


@property (strong, nonatomic) AGCourse *course;



@end
