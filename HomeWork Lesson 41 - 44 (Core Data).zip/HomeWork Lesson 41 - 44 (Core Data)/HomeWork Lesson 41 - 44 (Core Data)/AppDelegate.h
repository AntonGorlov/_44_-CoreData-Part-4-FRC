//
//  AppDelegate.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 06.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;



@end

