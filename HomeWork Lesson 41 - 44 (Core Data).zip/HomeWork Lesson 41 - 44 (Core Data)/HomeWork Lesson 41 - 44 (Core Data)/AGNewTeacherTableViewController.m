//
//  AGNewTeacherTableViewController.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 18.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGNewTeacherTableViewController.h"
#import "AGDataManager.h"
#import "AGTeacher+CoreDataProperties.h"
#import "AGTeachersViewController.h"
#import "AGUser+CoreDataProperties.h"
#import "AGAddCoreCell.h"
#import "AGCourse+CoreDataProperties.h"

@interface AGNewTeacherTableViewController () <UITextFieldDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITextField *firstNameTextField;
@property (strong, nonatomic) UITextField *lastNameTextField;

@end

@implementation AGNewTeacherTableViewController


- (void) setTeacher:(AGTeacher *)teacher {

    if (_teacher != teacher) {
        
        _teacher = teacher;
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.firstNameTextField becomeFirstResponder];
    
    UIBarButtonItem *saveNewTeacherAction = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveTeacherAction)];
    
    self.navigationItem.rightBarButtonItem = saveNewTeacherAction;
}

- (void)viewWillAppear:(BOOL)animated{
    
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Aactions

- (void) saveTeacherAction {

    
    if ([self.firstNameTextField.text length] == 0 || [self.lastNameTextField.text length] == 0) {
        UIAlertController *alertView = [UIAlertController alertControllerWithTitle:@"Error"
                                                                           message:@"Add name and surname for a techer"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alertView addAction:okAction];
        
        [self presentViewController:alertView animated:YES completion:nil];
        
        return;
        
    }
    
    if (!self.teacher) {
        
        AGTeacher *teacher = [NSEntityDescription insertNewObjectForEntityForName:@"AGTeacher" inManagedObjectContext:[[AGDataManager sharedManager] managedObjectContext]];
        
        
        teacher.firstName = self.firstNameTextField.text;
        teacher.lastName = self.lastNameTextField.text;
        self.teacher = teacher;
        
        [[[AGDataManager sharedManager] managedObjectContext] save:nil];

    }else {
    
        [self.teacher setValue:self.firstNameTextField.text forKey:@"firstName"];
        [self.teacher setValue:self.lastNameTextField.text forKey:@"lastName"];
        
    }
    
    [[[AGDataManager sharedManager]managedObjectContext] save:nil];
    [self.navigationController popViewControllerAnimated:YES ];
}

#pragma mark UITableViewDataSource

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {

    if (section == 0) {
        
        return @"Teacher";
        
    }else {
    
    return @"Teaches on:";
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if (section == 0) {
        
        return 2;
        
    }else {
    
        return [[self.teacher course] count];
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString *identifier = @"teacherCell";
    
    AGAddCoreCell *cell =[tableView dequeueReusableCellWithIdentifier:identifier];
    
    static NSString *identifierTeacher = @"Cell";
    UITableViewCell *cellTeacher = [tableView dequeueReusableCellWithIdentifier:identifierTeacher];
    
    if (!cellTeacher) {
        
        cellTeacher = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            
            cell.labelName.text = @"First name";
            self.firstNameTextField = cell.textFieldName;
            cell.textFieldName.placeholder = @"Add first name";
            cell.textFieldName.text = (!self.teacher) ? @"" : [[self.teacher valueForKey:@"firstName"] description];
            
        }else {
            
            cell.labelName.text = @"Last name";
            self.lastNameTextField = cell.textFieldName;
            cell.textFieldName.placeholder = @"Add last name";
            cell.textFieldName.text = (!self.teacher) ? @"" : [self.teacher valueForKey:@"lastName"];
            
        }
        return cell;
    }
    if (indexPath.section == 1) {
        
        NSArray *arrayStudents = [[self.teacher course] allObjects];
        cellTeacher.textLabel.text = [NSString stringWithFormat:@"%@", [[arrayStudents objectAtIndex:indexPath.row]nameCourse]];
        
    }
    return cellTeacher;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (indexPath.section == 1) {
            NSArray* arrayStudents = [[self.teacher course] allObjects];
            AGUser *user = (AGUser *)[arrayStudents objectAtIndex:indexPath.row];
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:arrayStudents];
            
            [tempArray removeObject:user];
            
            [self.teacher setCourse:[NSSet setWithArray:tempArray]];
            [[[AGDataManager sharedManager] managedObjectContext] save:nil];
            
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            
        }
    }
}

#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (textField == self.firstNameTextField) {
        
        [self.lastNameTextField becomeFirstResponder];
        
    }else {
        
        [textField resignFirstResponder];
        
    }
    return YES;
}
@end
