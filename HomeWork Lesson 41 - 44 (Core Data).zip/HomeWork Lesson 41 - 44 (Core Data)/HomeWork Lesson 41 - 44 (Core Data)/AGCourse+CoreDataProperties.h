//
//  AGCourse+CoreDataProperties.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 16.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGCourse.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGCourse (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *department;
@property (nullable, nonatomic, retain) NSString *nameCourse;
@property (nullable, nonatomic, retain) NSString *subject;
@property (nullable, nonatomic, retain) NSSet<AGUser *> *students;
@property (nullable, nonatomic, retain) AGTeacher *teacher;

@end

@interface AGCourse (CoreDataGeneratedAccessors)

- (void)addStudentsObject:(AGUser *)value;
- (void)removeStudentsObject:(AGUser *)value;
- (void)addStudents:(NSSet<AGUser *> *)values;
- (void)removeStudents:(NSSet<AGUser *> *)values;

@end

NS_ASSUME_NONNULL_END
