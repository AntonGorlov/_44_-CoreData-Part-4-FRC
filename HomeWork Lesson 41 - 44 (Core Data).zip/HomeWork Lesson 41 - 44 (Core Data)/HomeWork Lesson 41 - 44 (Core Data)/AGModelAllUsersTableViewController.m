//
//  AGModelAllUsersTableViewController.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 12.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGModelAllUsersTableViewController.h"
#import "AGDataManager.h"
#import "AGCoreDataViewController.h"
#import "AGUser+CoreDataProperties.h"
#import "AGNewCourseTableViewController.h"
#import "AGCourse+CoreDataProperties.h"
#import "AGTeacher+CoreDataProperties.h"

@interface AGModelAllUsersTableViewController () <UITableViewDelegate, UITableViewDataSource>

@end

@implementation AGModelAllUsersTableViewController


@synthesize fetchedResultsController = _fetchedResultsController;

- (void)setDetailItem:(id)newDetailItem {
    
    if (self.typeEntity == AGCoursesType) {
        
        if (_detailItem != newDetailItem) {
            _detailItem = (AGCourse*)newDetailItem;
        }
    }
    if (self.typeEntity == AGUsersType) {
        
        if (_detailItem != newDetailItem) {
            _detailItem = (AGUser*)newDetailItem;
        }
    }
    if (self.typeEntity == AGTeachersType) {
        
        if (_detailItem != newDetailItem) {
            _detailItem = newDetailItem;
        }
    }
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self insetsStatusBar];
    
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    [self.tableView setEditing:YES animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) insetsStatusBar {

    UIEdgeInsets insets = UIEdgeInsetsMake(14, 0, 0, 0);
    self.tableView.contentInset = insets;
}
#pragma mark - Fetched results controller

- (NSFetchedResultsController *)fetchedResultsController
{
    if (_fetchedResultsController != nil) {
        return _fetchedResultsController;
    }
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    // Edit the entity name as appropriate.
    NSEntityDescription *entity = nil;
    
    if (self.typeEntity == AGCoursesType) {
        
        entity = [NSEntityDescription entityForName:@"AGUser" inManagedObjectContext:self.managedObjectContext];
    }
    
    if (self.typeEntity == AGUsersType) {
        
        entity = [NSEntityDescription entityForName:@"AGCourse" inManagedObjectContext:self.managedObjectContext];
    }
    if (self.typeEntity == AGTeachersType) {
        
        entity = [NSEntityDescription entityForName:@"AGTeacher" inManagedObjectContext:self.managedObjectContext];
    }
    
    [fetchRequest setEntity:entity];
    
    // Set the batch size to a suitable number.
    [fetchRequest setFetchBatchSize:20];
    
    NSSortDescriptor *sortDescriptor = nil;
    
    if (self.typeEntity == AGCoursesType || self.typeEntity == AGTeachersType) {
        
         sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"firstName" ascending:NO];
        
    }else {
        

        sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"nameCourse" ascending:NO];
    }
    
    NSArray *sortDescriptors = @[sortDescriptor];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    // Edit the section name key path and cache name if appropriate.
    // nil for section name key path means "no sections".
    
    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:nil];
    aFetchedResultsController.delegate = self;
    self.fetchedResultsController = aFetchedResultsController;
    
    NSError *error = nil;
    if (![self.fetchedResultsController performFetch:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _fetchedResultsController;
}



- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView beginUpdates];
}

- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type
{
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        default:
            return;
    }
}

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath
{
    UITableView *tableView = self.tableView;
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
             case NSFetchedResultsChangeUpdate:
             [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
             break;
        /*
        case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] withObject:anObject];
            break;
         */
        case NSFetchedResultsChangeMove:
            [tableView moveRowAtIndexPath:indexPath toIndexPath:newIndexPath];
            break;
    }
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView endUpdates];
}


#pragma mark UITableViewDataSource
/*
- (void) configureCell:(UITableViewCell *)cell withObject:(NSManagedObject *)object {
    
     cell.textLabel.textColor = [UIColor blueColor];
    
    if (self.typeEntity == AGUsersType) {
       
        cell.textLabel.text = [[object valueForKey:@"descriptionNameCourse"]description];
    }
   
    if (self.typeEntity == AGCoursesType) {
        
        cell.textLabel.text = [[object valueForKey:@"descriptionNameLastName"] description];

    }
}
*/

- (void) configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {

    cell.textLabel.textColor = [UIColor blueColor];
    
    if (self.typeEntity == AGUsersType) {
        
        AGCourse *course = [self.fetchedResultsController objectAtIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", course.nameCourse, course.subject];
        
        if ([[self.detailItem courses] containsObject:course]) {
            [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionTop];
        }
    }
    
    if (self.typeEntity == AGCoursesType) {
        
        AGUser *user = [self.fetchedResultsController objectAtIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", user.firstName, user.lastName];
        
        if ([[self.detailItem students] containsObject:user]) {
            [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionTop];
        }
    }
    if (self.typeEntity == AGTeachersType) {
        
        AGTeacher *teacher = [self.fetchedResultsController objectAtIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", teacher.firstName, teacher.lastName];
    }
}

#pragma mark -UITableViewDataSource


#pragma mark - UIGestureRecognizer

- (void) dismissVC {
    
    [self dismissViewControllerAnimated:YES completion:^{
        NSLog(@"Dismiss AGModelAllUsersTableViewController");
    }];
    
}

#pragma mark - Actions

- (IBAction)actionCancel:(UIBarButtonItem *)sender {
    
    [self dismissVC];
}

- (IBAction)actionSave:(UIBarButtonItem *)sender {// with checkmark
    
    NSArray *selectedRows = [self.tableView indexPathsForSelectedRows];
    
    NSMutableArray *items = [NSMutableArray new];
    
    for (NSIndexPath *selectionIndex in selectedRows)
    {
        [items addObject:[self.fetchedResultsController objectAtIndexPath:selectionIndex]];
    }
    
    NSSet* set = [NSSet setWithArray:items];
    NSSet* removeSet = nil;
    
    if (self.typeEntity == AGCoursesType) {
        removeSet = [NSSet setWithArray:[[self.detailItem students] allObjects]];
        [self.detailItem removeStudents:removeSet];
        [self.detailItem addStudents:set];
    }
    if (self.typeEntity == AGUsersType) {
        removeSet = [NSSet setWithArray:[[self.detailItem courses] allObjects]];
        [self.detailItem removeCourses:removeSet];
        [self.detailItem addCourses:set];
    }
    if (self.typeEntity == AGTeachersType) {
        [self.detailItem setValue:[items firstObject] forKey:@"teacher"]; //one object

    }
    
    [self.managedObjectContext save:nil];
    
    NSLog(@"Save your choice");
    [self dismissVC];
    
}
@end
