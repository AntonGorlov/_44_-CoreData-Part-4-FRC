//
//  AGNewCourseTableViewController.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 08.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGNewCourseTableViewController.h"
#import "AGDataManager.h"
#import "AGCourse+CoreDataProperties.h"
#import "AGModelAllUsersTableViewController.h"
#import "AGNewUserTableViewController.h"
#import "AGUser+CoreDataProperties.h"
#import "AGTeacher+CoreDataProperties.h"

@interface AGNewCourseTableViewController () <UITextFieldDelegate>

@property (strong, nonatomic) UITextField* nameCourseTextField;
@property (strong, nonatomic) UITextField* subjectTextField;
@property (strong, nonatomic) UITextField* departmentTextField;

@end

@implementation AGNewCourseTableViewController


#pragma mark - Managing the detail item

- (void)setCourse:(id)course {
    
    if (_course != course) {
        
        _course = course;
        
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.nameCourseTextField becomeFirstResponder];
    
    if (self.course != nil) {
        
        self.nameCourseTextField.text = _course.nameCourse;
        self.subjectTextField.text = _course.subject;
        self.departmentTextField.text = _course.department;
    }
    
    
    UIBarButtonItem *actionSaveCourse = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveCourseAction:)];
    
    self.navigationItem.rightBarButtonItem = actionSaveCourse;
}

- (void)viewWillAppear:(BOOL)animated{
    
    [self.tableView reloadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -Actions

- (void) saveCourseAction:(id) sender {
    
    if ([self.nameCourseTextField.text length] == 0 || [self.subjectTextField.text length] == 0 || [self.departmentTextField.text length] == 0) {
        
        UIAlertController *alertError = [UIAlertController alertControllerWithTitle:@"Error!" message:@"Add name course" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alertError addAction:okAction];
        
        [self presentViewController:alertError animated:YES completion:nil];
        
        return;
    }
        
    if (!self.course) {
        
        AGCourse *course =
        [NSEntityDescription insertNewObjectForEntityForName:@"AGCourse"
                                      inManagedObjectContext:[[AGDataManager sharedManager] managedObjectContext]];
        
        course.nameCourse = self.nameCourseTextField.text;
        course.subject = self.subjectTextField.text;
        course.department = self.departmentTextField.text;
        
        self.course = course;
        
        [[[AGDataManager sharedManager]managedObjectContext] save:nil];
        
    }else{
        
        [self.course setValue:self.nameCourseTextField.text forKey:@"nameCourse"];
        [self.course setValue:self.subjectTextField.text forKey:@"subject"];
        [self.course setValue:self.departmentTextField.text forKey:@"department"];
        
    }
    
    [[[AGDataManager sharedManager]managedObjectContext]save:nil];
    
    
    [self.navigationController popViewControllerAnimated:YES];

}


#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return 3;
        
    }else if(section == 1){
        
        return [[self.course students] count]+1;
        
    }else{
        
        return 1;
        
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return @"User info";
        
    } else if(section == 1) {
        
        return @"User courses";
        
    }
    
    else{
        
        return @"Teacher";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString* identifier = @"courseCell";
    static NSString* identifierStudent = @"cell";
    static NSString* identifierAdd = @"cellAdd";

    AGAddCoreCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    UITableViewCell *cellStudents = [tableView dequeueReusableCellWithIdentifier:identifierStudent];
    UITableViewCell *cellAdd = [tableView dequeueReusableCellWithIdentifier:identifierAdd];

    
    if (indexPath.section == 0) {
    
        if (indexPath.row == 0) {
            cell.labelName.text = @"Name course";
            cell.textFieldName.placeholder = @"Add name";
            self.nameCourseTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.course) ? @"" : [[self.course valueForKey:@"nameCourse"] description];
        }
    
        if (indexPath.row == 1) {
            cell.labelName.text = @"Subject";
            cell.textFieldName.placeholder = @"Add subject name";
            self.subjectTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.course) ? @"" : [[self.course valueForKey:@"subject"] description];
            
        }
        if (indexPath.row == 2) {
            cell.labelName.text = @"Department";
            cell.textFieldName.placeholder = @"Add department name";
            self.departmentTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.course) ? @"" : [[self.course valueForKey:@"department"] description];
        }
        
        return cell;
        
    }
    if (!cellAdd) {
        
        cellAdd = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierAdd];
    }
    if (indexPath.section == 1){
        if (indexPath.row == 0) {
            cellAdd.textLabel.text = @"ADD STUDENT";
            cellAdd.textLabel.textColor = [UIColor blueColor];
            cellAdd.textLabel.textAlignment = NSTextAlignmentCenter;
            return cellAdd;
            
        }else{
            
            if (!cellStudents) {
                cellStudents = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierStudent];
            }
            
            NSArray* arrayStudents = [[self.course students] allObjects];
            cellStudents.textLabel.text = [NSString stringWithFormat:@"%@ %@ ",[[arrayStudents objectAtIndex:indexPath.row-1] firstName],[[arrayStudents objectAtIndex:indexPath.row-1] lastName]];
            
            return cellStudents;
        }
    }
    
    if (indexPath.section == 2){
        if ([self.course teacher] == nil) {
            
            cellAdd.textLabel.text = @"ADD TEACHER";
            cellAdd.textLabel.textColor = [UIColor blueColor];
            cellAdd.textLabel.textAlignment = NSTextAlignmentCenter;
            
        }else{
            cellAdd.textLabel.text = [NSString stringWithFormat:@"%@ %@",[[self.course teacher] firstName], [[self.course teacher] lastName]];
        }
        return cellAdd;
    }

    
    
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return NO;
    }
    if (indexPath.section == 1 && indexPath.row == 0) {
        return NO;
    }
    
    if (indexPath.section == 2 && [self.course teacher] == nil) {
        return NO;
    }
     
    return YES;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if (indexPath.section == 1 && indexPath.row == 0) {
        
        if (!self.course) {
            UIAlertController *alertError = [UIAlertController alertControllerWithTitle:@"Error" message:@"Add name course and press save button" preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *actionError = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertError addAction:actionError];
            
            return;
        }
        AGModelAllUsersTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGModelAllUsersTableViewController"];
        vc.typeEntity = AGCoursesType;
        vc.detailItem = self.course;
        [self presentViewController:vc animated:YES completion:nil];
    }
    if (indexPath.section == 1 && indexPath.row != 0) {
        
        AGNewUserTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGNewUserTableViewController"];
        
        NSArray* arrayStudents = [[self.course students] allObjects];
        AGUser *students = (AGUser *)[arrayStudents objectAtIndex:indexPath.row-1];
        
        vc.user = students;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.section == 2 && indexPath.row == 0) {
        if (!self.course) {
            
            UIAlertController *alertError = [UIAlertController alertControllerWithTitle:@"Error" message:@"Add name course and press save button" preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *actionError = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertError addAction:actionError];
            return;
        }
        
        AGModelAllUsersTableViewController* vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGModelAllUsersTableViewController"];
        vc.typeEntity = AGTeachersType;
        vc.detailItem = self.course;
        [self presentViewController:vc animated:YES completion:nil];
        
    }
    
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (indexPath.section == 1 && indexPath.row != 0 ) {
            
            NSArray *allUsers = [[self.course students] allObjects];
            
            AGUser *user = (AGUser*) [allUsers objectAtIndex:indexPath.row -1];
            
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:allUsers];
            
            [tempArray removeObject:user];
            
            [self.course setStudents:[NSSet setWithArray:tempArray]];
            
            [[[AGDataManager sharedManager] managedObjectContext] save:nil];
            
            [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
                        
        }
    }
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (textField == self.nameCourseTextField) {
        
        [self.subjectTextField becomeFirstResponder];
        
    } else if (textField == self.subjectTextField)  {
        
        [self.departmentTextField becomeFirstResponder];
        
    } else {
        
        [textField resignFirstResponder];
        
    }
    return YES;
}
@end
