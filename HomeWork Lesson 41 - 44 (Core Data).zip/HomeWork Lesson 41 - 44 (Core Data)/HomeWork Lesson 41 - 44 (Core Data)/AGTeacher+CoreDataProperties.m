//
//  AGTeacher+CoreDataProperties.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 16.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGTeacher+CoreDataProperties.h"

@implementation AGTeacher (CoreDataProperties)

@dynamic firstName;
@dynamic lastName;
@dynamic course;

@end
