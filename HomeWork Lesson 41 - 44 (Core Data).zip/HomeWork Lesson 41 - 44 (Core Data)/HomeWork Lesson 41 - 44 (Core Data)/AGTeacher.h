//
//  AGTeacher.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 16.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGObject.h"

@class AGCourse;

NS_ASSUME_NONNULL_BEGIN

@interface AGTeacher : AGObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "AGTeacher+CoreDataProperties.h"
