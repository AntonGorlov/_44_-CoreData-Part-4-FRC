//
//  AGNewUserTableViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 06.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AGAddCoreCell.h"

@class AGUser;

@interface AGNewUserTableViewController : UITableViewController

@property (strong, nonatomic) AGUser *user;





@end
