//
//  AGObject.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 16.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGObject.h"

@implementation AGObject

// Insert code here to add functionality to your managed object subclass

@end
