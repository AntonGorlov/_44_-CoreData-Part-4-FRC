//
//  AGCoursesViewController.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 08.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCoursesViewController.h"
#import "AGNewCourseTableViewController.h"
#import "AGCourse+CoreDataProperties.h"


@interface AGCoursesViewController () <UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate>

@end

@implementation AGCoursesViewController

@synthesize fetchedResultsController = _fetchedResultsController;

- (void)viewDidLoad {
    [super viewDidLoad];
   
    UIBarButtonItem *actionAddCourse = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                                    target:self
                                                                                    action:@selector(createCourseAction)];
    
    self.navigationItem.rightBarButtonItem = actionAddCourse;
    
    
    UIBarButtonItem *actionDeleteAllCourse = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:self action:@selector(deleteAllCoursesAction)];
    
    self.navigationItem.leftBarButtonItem = actionDeleteAllCourse;
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor redColor];
}

- (void)viewWillAppear:(BOOL)animated{ //averytime update the table
    
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) deleteAllCoursesAction {

    NSArray *allObjects = [self allObjectsCourses];
    
    for (id object in allObjects) {
        
        [self.managedObjectContext deleteObject:object];
        
        NSError *error = nil;
        
        if (![self.managedObjectContext save:&error]) {
            
            NSLog(@"%@",[error localizedDescription]);
        }
    }
    
    NSLog(@"Delete all courses");
}
- (NSArray*) allObjectsCourses {

    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    // Edit the entity name as appropriate.
   NSEntityDescription *description = [NSEntityDescription entityForName:@"AGCourse" inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:description];
    
    NSError *requestError = nil;
    NSArray *resultArray = [self.managedObjectContext executeFetchRequest:fetchRequest error:&requestError];

    if (requestError) {
        
        NSLog(@"%@",[requestError localizedDescription]);
    }
    return resultArray;
}
#pragma mark - Fetched results controller

- (NSFetchedResultsController *)fetchedResultsController
{
    if (_fetchedResultsController != nil) {
        return _fetchedResultsController;
    }
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    // Edit the entity name as appropriate.
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"AGCourse" inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    
    // Set the batch size to a suitable number.
    [fetchRequest setFetchBatchSize:20];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *nameCourseDescriptor = [[NSSortDescriptor alloc] initWithKey:@"nameCourse" ascending:YES];
    
    [fetchRequest setSortDescriptors:@[nameCourseDescriptor ]];
    
    // Edit the section name key path and cache name if appropriate.
    // nil for section name key path means "no sections".
    
    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:nil];
    aFetchedResultsController.delegate = self;
    self.fetchedResultsController = aFetchedResultsController;
    
    NSError *error = nil;
    if (![self.fetchedResultsController performFetch:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _fetchedResultsController;
}


- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView beginUpdates];
}

- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type
{
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        default:
            return;
    }
}

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath
{
    UITableView *tableView = self.tableView;
    
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
        case NSFetchedResultsChangeDelete:
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
            
             case NSFetchedResultsChangeUpdate:
             [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
             break;
         /*
        case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] withObject:anObject];
            break;
         */
        case NSFetchedResultsChangeMove:
            [tableView moveRowAtIndexPath:indexPath toIndexPath:newIndexPath];
            break;
    }
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView endUpdates];
}


- (void) createCourseAction {

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGNewCourseTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGNewCourseTableViewController"];
    
    
    [self.navigationController pushViewController:vc animated:YES];

}


#pragma mark UITableViewDataSource
/*
- (void)configureCell:(UITableViewCell *)cell withObject:(NSManagedObject *)object {

    cell.textLabel.textColor = [UIColor blueColor];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    
    cell.textLabel.text = [[object valueForKey:@"descriptionNameCourse"]description];
    cell.detailTextLabel.text = [[object valueForKey:@"descriptionSubjectAndDepartment"]description];
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}
*/

- (void) configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    
    cell.textLabel.textColor = [UIColor blueColor];
    cell.detailTextLabel.textColor = [UIColor grayColor];
    
    AGCourse *course = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", course.nameCourse, course.subject];
    cell.detailTextLabel.text = course.department;
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    AGCourse *course = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGNewCourseTableViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"AGNewCourseTableViewController"];
    
    vc.course = course;
    
    [self.navigationController pushViewController:vc animated:YES];


}

@end
