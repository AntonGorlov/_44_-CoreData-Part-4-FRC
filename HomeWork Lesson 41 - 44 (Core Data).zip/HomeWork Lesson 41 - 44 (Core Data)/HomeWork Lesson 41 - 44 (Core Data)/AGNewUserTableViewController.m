//
//  AGNewUserTableViewController.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 06.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGNewUserTableViewController.h"
#import "AGDataManager.h"
#import "AGUser+CoreDataProperties.h"
#import "AGCourse+CoreDataProperties.h"
#import "AGModelAllUsersTableViewController.h"
#import "AGNewCourseTableViewController.h"

@interface AGNewUserTableViewController () <UITextFieldDelegate, UITableViewDataSource>


@property (strong, nonatomic) UITextField* firstNameTextField;
@property (strong, nonatomic) UITextField* lastNameTextField;
@property (strong, nonatomic) UITextField* emailTextField;

@end

@implementation AGNewUserTableViewController

#pragma mark - Managing the detail item

- (void)setUser:(id)user {
    
    if (_user != user) {
        
        _user = user;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
 
    [self.firstNameTextField becomeFirstResponder];
 /*
    if (self.user != nil) { //для редактирования полей 
        
        self.firstNameTextField.text = _user.firstName;
        self.lastNameTextField.text = _user.lastName;
        self.emailTextField.text = _user.eMail;
    }
 */
    UIBarButtonItem *saveUser = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(addNewUserAction:)]; //add save button

    self.navigationItem.rightBarButtonItem = saveUser;
}

- (void)viewWillAppear:(BOOL)animated{
    
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Actions

- (void) addNewUserAction:(id) sender {
 
    if ([self.firstNameTextField.text length] == 0 || [self.lastNameTextField.text length] == 0 || [self.emailTextField.text length] == 0) {
        
        UIAlertController *alertError = [UIAlertController alertControllerWithTitle:@"Error" message:@"Add name, surname and e-mail user" preferredStyle:UIAlertControllerStyleAlert];
       
        
        UIAlertAction *actionError = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:nil];
        
        [alertError addAction:actionError];
        
          [self presentViewController:alertError animated:YES completion:nil];
        
        return;
    }
        if (!self.user) {
            
            AGUser* user =
            [NSEntityDescription insertNewObjectForEntityForName:@"AGUser"
                                          inManagedObjectContext:[[AGDataManager sharedManager] managedObjectContext]];
            user.firstName = self.firstNameTextField.text;
            user.lastName = self.lastNameTextField.text;
            user.eMail = self.emailTextField.text;
            
        }else{
            [self.user setValue:self.firstNameTextField.text forKey:@"firstName"]; //KVC
            [self.user setValue:self.lastNameTextField.text forKey:@"lastName"];
            [self.user setValue:self.emailTextField.text forKey:@"eMail"];
        }
        [[[AGDataManager sharedManager] managedObjectContext] save:nil];
        
        [self.navigationController popViewControllerAnimated:YES];
        
}

#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return 3;
        
    }else{
        
        return [[self.user courses] count] + 1;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return @"Profile";
        
    } else  {
        
        return @"Other";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"studentCell";

    AGAddCoreCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    static NSString* identifierStudent = @"Cell";
    UITableViewCell *cellStudent = [tableView dequeueReusableCellWithIdentifier:identifierStudent];
    
    if (!cellStudent) {
        cellStudent = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }

    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.labelName.text = @"First Name";
            cell.textFieldName.placeholder = @"Add first name";
            self.firstNameTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.user) ? @"" : [[self.user valueForKey:@"firstName"] description];
        }
        if (indexPath.row == 1) {
            cell.labelName.text = @"Last Name";
            cell.textFieldName.placeholder = @"Add last name";
            self.lastNameTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.user) ? @"" : [[self.user valueForKey:@"lastName"] description];
        }
        if (indexPath.row == 2) {
            cell.labelName.text = @"E-Mail";
            cell.textFieldName.placeholder = @"Add email";
            self.emailTextField = cell.textFieldName;
            cell.textFieldName.text = (!self.user) ? @"" : [[self.user valueForKey:@"eMail"] description];
            
        }
        return cell;
    }

    if (indexPath.section == 1) {
        
        if (indexPath.row == 0) {
            cellStudent.textLabel.text = @"Add Course";
            cellStudent.textLabel.textColor = [UIColor blueColor];
            cellStudent.textLabel.textAlignment = NSTextAlignmentCenter;
            
        }else{
            
            NSArray* arrayStudents = [[self.user courses] allObjects];
            cellStudent.textLabel.text = [[arrayStudents objectAtIndex:indexPath.row - 1] nameCourse];
        }
        return cellStudent;
    }

    return NO;

}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if (indexPath.section == 1 && indexPath.row != 0) {
            
            NSArray* arrayStudents = [[self.user courses] allObjects];
            
            AGCourse *course = (AGCourse *)[arrayStudents objectAtIndex:indexPath.row-1];
            NSMutableArray *tempArray = [NSMutableArray arrayWithArray:arrayStudents];
            
            [tempArray removeObject:course];
            
            [self.user setCourses:[NSSet setWithArray:tempArray]];
            [[[AGDataManager sharedManager] managedObjectContext] save:nil];
            
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            
        }
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        
        return NO;
    }
    return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.section == 1 && indexPath.row == 0 ) {
        if (!self.user) {
            
            UIAlertController *alertError = [UIAlertController alertControllerWithTitle:@"Error" message:@"Add name student and press save button" preferredStyle:UIAlertControllerStyleActionSheet];
            
            UIAlertAction *actionAlertError = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertError addAction:actionAlertError];
            return;
        }
        AGModelAllUsersTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGModelAllUsersTableViewController"];
        vc.typeEntity = AGUsersType;
        vc.detailItem = self.user;
        
        [self presentViewController:vc animated:YES completion:nil];
        
    }
    if (indexPath.section == 1 && indexPath.row != 0) {
     
      //нажатие на ячейку
        AGNewCourseTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AGNewCourseTableViewController"];
        
        NSArray* arrayStudents = [[self.user courses] allObjects];
        AGCourse *course = (AGCourse *)[arrayStudents objectAtIndex:indexPath.row-1];
        
        vc.course = course;
        
        [self.navigationController pushViewController:vc animated:YES];
      
    }

}

#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (textField == self.firstNameTextField) {
        
        [self.lastNameTextField becomeFirstResponder];
        
    } else if (textField == self.lastNameTextField)  {
        
        [self.emailTextField becomeFirstResponder];
        
    } else {
        
        [textField resignFirstResponder];
        
    }
    return YES;
}

@end
