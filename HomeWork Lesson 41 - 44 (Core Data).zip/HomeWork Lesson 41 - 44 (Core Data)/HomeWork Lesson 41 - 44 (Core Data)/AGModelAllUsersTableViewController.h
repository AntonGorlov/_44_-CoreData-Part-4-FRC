//
//  AGModelAllUsersTableViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 12.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AGCoreDataViewController.h"



typedef enum {
    
    AGUsersType,
    AGCoursesType,
    AGTeachersType
    
} AGDataType;

@interface AGModelAllUsersTableViewController : AGCoreDataViewController <NSFetchedResultsControllerDelegate>


@property (strong, nonatomic) id detailItem;
@property (assign, nonatomic) AGDataType typeEntity;

- (IBAction)actionCancel:(UIBarButtonItem *)sender;
- (IBAction)actionSave:(UIBarButtonItem *)sender;

@end
