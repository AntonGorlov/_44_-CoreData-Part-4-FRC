//
//  AGAddCoreCell.m
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 13.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGAddCoreCell.h"

@implementation AGAddCoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
