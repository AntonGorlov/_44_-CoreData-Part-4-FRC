//
//  AGCoreDataViewController.h
//  HomeWork Lesson 41 - 44 (Core Data)
//
//  Created by Anton Gorlov on 06.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@class AGUsersViewController, AGUser , AGCoursesViewController, AGCourses;
@interface AGCoreDataViewController : UITableViewController <NSFetchedResultsControllerDelegate>

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;



- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;

//- (void)configureCell:(UITableViewCell *)cell withObject:(NSManagedObject *)object; //до определенного момента использовал этот метод,но в классе AGModelAllUsersTableViewController ,не смог сделать  CheckMark (выдиление(галочки))по этому ПОЛНОСТЬЮ ВО ВСЕМ ПРОЕКТЕ МЕНЯЮ ЭТОТ МЕТОД НА - (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;

@end
