//
//  AGCourse+CoreDataProperties.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGCourse.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGCourse (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSSet<AGStudent *> *students;
@property (nullable, nonatomic, retain) AGUniversity *university;

@end

@interface AGCourse (CoreDataGeneratedAccessors)

- (void)addStudentsObject:(AGStudent *)value;
- (void)removeStudentsObject:(AGStudent *)value;
- (void)addStudents:(NSSet<AGStudent *> *)values;
- (void)removeStudents:(NSSet<AGStudent *> *)values;

@end

NS_ASSUME_NONNULL_END
