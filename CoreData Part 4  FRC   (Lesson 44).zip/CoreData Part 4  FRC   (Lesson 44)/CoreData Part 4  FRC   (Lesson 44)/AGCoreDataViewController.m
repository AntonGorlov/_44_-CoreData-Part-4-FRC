//
//  AGCoreDataViewController.m
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCoreDataViewController.h"
#import "AGDataManager.h"

@interface AGCoreDataViewController () 

@end

@implementation AGCoreDataViewController

- (instancetype)init
{
    self = [super initWithStyle:UITableViewStylePlain]; //стиль наших таблиц
    if (self) {
        
    }
    return self;
}
//переопределим геттер
- (NSManagedObjectContext*) managedObjectContext { //если кто-то запросит контекст,мы не будем идти в AppDelegate

    if (!_managedObjectContext) { //если нет такого контекста
        
        _managedObjectContext = [[AGDataManager sharedManager]managedObjectContext]; //наш managedObjectContext будет равен sharedManager
    }
    return _managedObjectContext;
}

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

//вставили  с шаблона (Apple) Table View
#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return [[self.fetchedResultsController sections] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    id <NSFetchedResultsSectionInfo> sectionInfo = [self.fetchedResultsController sections][section];
    return [sectionInfo numberOfObjects];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
//  NSManagedObject *object = [[self fetchedResultsController] objectAtIndexPath:indexPath];
    [self configureCell:cell atIndexPath:indexPath];
    
//  [self configureCell:cell withObject:object];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSManagedObjectContext *context = [self.fetchedResultsController managedObjectContext];
        [context deleteObject:[self.fetchedResultsController objectAtIndexPath:indexPath]];
        
        NSError *error = nil;
        if (![context save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}


- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath*) indexPath {
   //у каждого класса этот метод будет свой
}

/*
- (void)configureCell:(UITableViewCell *)cell withObject:(NSManagedObject *)object {
     //у каждого класса этот метод будет свой
}
 */
@end
