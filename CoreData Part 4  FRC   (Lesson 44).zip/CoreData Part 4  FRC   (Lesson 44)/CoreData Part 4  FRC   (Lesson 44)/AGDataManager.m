//
//  AGDataManager.m
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDataManager.h"
#import "AGUniversity+CoreDataProperties.h"
#import "AGCourse+CoreDataProperties.h"
#import "AGStudent+CoreDataProperties.h"
#import "AGCar+CoreDataProperties.h"
#import "AGObject+CoreDataProperties.h"

@implementation AGDataManager

+(AGDataManager*) sharedManager { //делаем метод класса,который возвращает обьект данного класса
    
    static AGDataManager *manager = nil; //делаем статический указатель (если он nil - не существует),то ставим его в переменную и возвращаем,если существует, то мы его возвращаем.
    static dispatch_once_t onceToken; //защещает от паралельных потоков
    dispatch_once(&onceToken, ^{
        manager = [[AGDataManager alloc]init];
       
    });
    return manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
      //  [self generateAndAddUniversity]; //вызываем БД (с печатью)
        
      //  [self deleteAllObjects]; //удаляем БД
        [self printAllObjects]; //печатаем БД
    }
    return self;
}
static NSString *firstNames[] = {
    @"Tran", @"Lenore", @"Bud", @"Fredda", @"Katrice",
    @"Clyde", @"Hildegard", @"Vernell", @"Nellie", @"Rupert",
    @"Billie", @"Tamica", @"Crystle", @"Kandi", @"Caridad",
    @"Vanetta", @"Taylor", @"Pinkie", @"Ben", @"Rosanna",
    @"Eufemia", @"Britteny", @"Ramon", @"Jacque", @"Telma",
    @"Colton", @"Monte", @"Pam", @"Tracy", @"Tresa",
    @"Willard", @"Mireille", @"Roma", @"Elise", @"Trang",
    @"Ty", @"Pierre", @"Floyd", @"Savanna", @"Arvilla",
    @"Whitney", @"Denver", @"Norbert", @"Meghan", @"Tandra",
    @"Jenise", @"Brent", @"Elenor", @"Sha", @"Jessie"
};

static NSString *lastNames[] = {
    @"Farrah", @"Laviolette", @"Heal", @"Sechrest", @"Roots",
    @"Homan", @"Starns", @"Oldham", @"Yocum", @"Mancia",
    @"Prill", @"Lush", @"Piedra", @"Castenada", @"Warnock",
    @"Vanderlinden", @"Simms", @"Gilroy", @"Brann", @"Bodden",
    @"Lenz", @"Gildersleeve", @"Wimbish", @"Bello", @"Beachy",
    @"Jurado", @"William", @"Beaupre", @"Dyal", @"Doiron",
    @"Plourde", @"Bator", @"Krause", @"Odriscoll", @"Corby",
    @"Waltman", @"Michaud", @"Kobayashi", @"Sherrick", @"Woolfolk",
    @"Holladay", @"Hornback", @"Moler", @"Bowles", @"Libbey",
    @"Spano", @"Folson", @"Arguelles", @"Burke", @"Rook"
};

//50 шт

static NSString* carModels [] = { @"Zaz", @"BMW", @"Volvo",@"VAZ", @"Renault"};


- (AGStudent*) addRandomStudent {
    
    AGStudent *student = [NSEntityDescription insertNewObjectForEntityForName:@"AGStudent" inManagedObjectContext:self.managedObjectContext];
    
    student.score = @((float)arc4random_uniform(201) /100.f + 2.f); //от 2 до 4х
    student.dateOfBirth = [NSDate dateWithTimeIntervalSince1970:60 * 60 * 24 * 365 *arc4random_uniform(31)]; // от 1970 до 2000;
    student.firstName = firstNames [arc4random_uniform(50)];
    student.lastName = lastNames [arc4random_uniform(50)];
    
    return student;
};

- (AGCar*) addRandomCar {
    
    AGCar *car = [NSEntityDescription insertNewObjectForEntityForName:@"AGCar" inManagedObjectContext:self.managedObjectContext];
    
    car.model = carModels [arc4random_uniform(5)]; //от 0 до 5
    
    return car;
}
//TODO: add another University

- (AGUniversity*) createUniversity {
    
    AGUniversity *university = [NSEntityDescription insertNewObjectForEntityForName:@"AGUniversity" inManagedObjectContext:self.managedObjectContext];
    
    university.name = @"KPI";
    
    return university;
}


- (AGCourse*) addCourseWithName:(NSString*) name { //используем другой конструктор,не такой как в carModels (static NSString *firstNames[])
    AGCourse *course = [NSEntityDescription insertNewObjectForEntityForName:@"AGCourse" inManagedObjectContext:self.managedObjectContext];
    
    course.name = name;
    
    return course;
}

- (NSArray*) allObjects { //вывели в отдельный метод, чтобы код не повторялся в printAllObjects и deleteAllObjects
    
    //считываем данные у БД
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
    
    NSEntityDescription *description = [NSEntityDescription entityForName:@"AGObject" inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:description];
    
    NSError *requestError = nil;
    NSArray *resultArray = [self.managedObjectContext executeFetchRequest:fetchRequest error:&requestError]; //request осущ-ен в Context. executeFetchRequest возвращает массив данных (execute - выполнение)
    
    if (requestError) {
        
        NSLog(@"%@",[requestError localizedDescription]);
    }
    return resultArray;
}


- (void) printArray:(NSArray*) array { //переопределим метод,чтобы можно было печатать массив (мы хотим печатать один массив, чтобы не дублировался код) c метода printAllObjects перекинули все кроме одной строки.Фактически ничего не изменилось,зато появилась функция печатать массив
    
    for (id object in array) {
        
        if ([object isKindOfClass:[AGCar class]]) {
            
            AGCar *car = (AGCar*) object; //приведения типов
            NSLog(@"Car %@, \n Owner: %@ %@ \n", car.model, car.owner.firstName, car.owner.lastName);
        }
        else if ([object isKindOfClass:[AGStudent class]]) {
            
            AGStudent *student = (AGStudent*) object;
            NSLog(@"  Student : %@ %@,  , score:%@, Courses: %lu",student.firstName, student.lastName, student.score, [student.courses count]);// уберем Car ,чтобы БД лучше читалась в консоли (мусолит глаза) Car : %@,  student.car.model,
        }
        else if ([object isKindOfClass:[AGUniversity class]]) {
            
            AGUniversity *university = (AGUniversity*) object;
            
            NSLog(@"University: %@ , students count %lu", university.name, [university.students count]);
            
        }
        else if ([object isKindOfClass:[AGCourse class]]) { //если есть курс - печатаем
            
            AGCourse *course = (AGCourse*) object;
            
            NSLog(@"Course:%@ students:%lu",course.name, [course.students count]);
        }
    }
    NSLog(@" array Count: %lu",[array count]); //кол-во обьектов
    
}

- (void) printAllObjects {
    
    NSArray *allObject = [self allObjects];
    
    [self printArray:allObject]; //теперь печатаем от сюда
    
}

- (void) deleteAllObjects {
    
    NSArray *allObject = [self allObjects]; //получаем все обьекты
    
    for (id object in allObject) {
        
        [self.managedObjectContext deleteObject:object]; //заходим в контекст,контекст не удаляет все обьекты, он помечает на удаление
    }
    [self.managedObjectContext save:nil]; //само удаление происходит,когда делаем save
    
}


- (void) generateAndAddUniversity  { //метод вместо - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:
    
    NSError *error = nil;
    
    //соз универ
 //закомментируем,чтобы при следующем запуске у нас не добавлялись новые студенты (машины,курсы и т.д)
    
     AGUniversity *university = [self createUniversity];
    
     //соз 5 курсов, потом каждому студенту добавляем рендомно
     
     NSArray *courses = [NSArray arrayWithObjects:[self addCourseWithName:@"iOS"],
                                                 [self addCourseWithName:@"PHP"],
                                                 [self addCourseWithName:@"Android"],
                                                 [self addCourseWithName:@"Java"],
                                                 [self addCourseWithName:@"jQuery"], nil];
    
     [university addCourses:[NSSet setWithArray:courses]]; //добавляем универу курсы
    
     //соз студентов
     
     for (int i = 0; i < 100; i++) {
     
     AGStudent *student = [self addRandomStudent];
     
     if (arc4random_uniform(1000) < 500) { // если сгенерировать число от "0" "1000" меньше чем 500 (50%) не берем от "0" и до "1" не всегда точное ,то
     
     AGCar *car = [self addRandomCar]; //соз машины
     student.car = car; //у студента машина (так как у нас установлена связь (Inverse), то для машины property "student"  установилось автоматом)
     }
     
     student.university = university; //у студента универ - этот универ,мы не добавляем студента в универ,так как у нас есть Inverse (ниже метод)
     //[university addStudentsObject:student];
     
     //добавляем рендомно курсы студенту
     NSInteger number = arc4random_uniform(5) + 1; // от 1 до 5
     
     while ([student.courses count] < number) { //У студента кол-во курсов (делаем ,чтобы не подписать 2 раза на один и тот же курс)
     
     AGCourse *course = [courses objectAtIndex:arc4random_uniform(5)]; // берем рендомно курс из массива (индекс в массиве от "0" до  "4" ставим "5")
     
     if (![student.courses containsObject:course]) { //если в курсах студента есть этот курс,который только что рендомно сделали, то ничего не делаем, если нет - добавлем курс
     
     [student addCoursesObject:course];
     }
     }
     
     }
     
     if (![self.managedObjectContext save:&error]) { //сохраняем,если не сохр -ошибка
     
     NSLog(@"%@",[error localizedDescription]);
     }
     
     [self printAllObjects]; // Печатаем БД

    // [self deleteAllObjects]; // чистим БД
    
    NSFetchRequest* request = [[NSFetchRequest alloc] init];
    
    NSEntityDescription* description =[NSEntityDescription entityForName:@"AGObject" inManagedObjectContext:self.managedObjectContext]; //EСЛИ ПАДАЕТ APP- МЕНЯЙ entityForName НА ДРУГОЕ!!!
    
    [request setEntity:description];
    
    NSError* requestError = nil;
    NSArray* resultArray = [self.managedObjectContext executeFetchRequest:request error:&requestError];
    
    
    [self printArray:resultArray];
}
    


//все скопировано с AppDELEGATE
#pragma mark - Core Data stack

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

- (NSURL *)applicationDocumentsDirectory {
    // The directory the application uses to store the Core Data store file. This code uses a directory named "Anton-Gorlov.CoreData_Part_4__FRC____Lesson_44_" in the application's documents directory.
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSManagedObjectModel *)managedObjectModel {
    // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"CoreData_Part_4__FRC____Lesson_44_" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    // The persistent store coordinator for the application. This implementation creates and returns a coordinator, having added the store for the application to it.
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    
    // Create the coordinator and store
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"CoreData_Part_4__FRC____Lesson_44_.sqlite"];
    NSError *error = nil;
    NSString *failureReason = @"There was an error creating or loading the application's saved data.";
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        // Report any error we got.
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSLocalizedDescriptionKey] = @"Failed to initialize the application's saved data";
        dict[NSLocalizedFailureReasonErrorKey] = failureReason;
        dict[NSUnderlyingErrorKey] = error;
        error = [NSError errorWithDomain:@"YOUR_ERROR_DOMAIN" code:9999 userInfo:dict];
        // Replace this with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}


- (NSManagedObjectContext *)managedObjectContext {
    // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.)
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    return _managedObjectContext;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}


@end
