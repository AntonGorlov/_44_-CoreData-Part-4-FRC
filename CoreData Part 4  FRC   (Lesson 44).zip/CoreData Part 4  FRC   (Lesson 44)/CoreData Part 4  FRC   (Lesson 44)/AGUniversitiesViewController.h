//
//  AGUniversitiesViewController.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 01.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCoreDataViewController.h"


@interface AGUniversitiesViewController : AGCoreDataViewController



@end
