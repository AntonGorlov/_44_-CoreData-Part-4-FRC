//
//  AGCoreDataViewController.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

//создали контроллер общий предок для всех остальных контоллеров (универ,студент,машина),чтобы не копировать с шаблона (по CD) pragma mark TableView в каждый контроллер

@interface AGCoreDataViewController : UITableViewController <NSFetchedResultsControllerDelegate> //подпишемся на Delegate

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext; //соз чтобы не обращаться каждый раз у контексту через (AGDataManager*) sharedManager managedObjectContext

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;


- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath*) indexPath; //этот метод у каждого контроллера будет свой (чтобы наследники знали)

//- (void)configureCell:(UITableViewCell *)cell withObject:(NSManagedObject *)object;

@end
