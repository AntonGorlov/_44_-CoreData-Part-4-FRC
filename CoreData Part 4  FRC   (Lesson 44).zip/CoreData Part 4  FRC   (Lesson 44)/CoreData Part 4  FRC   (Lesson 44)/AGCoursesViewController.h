//
//  AGCoursesViewController.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 05.09.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCoreDataViewController.h"

@class AGUniversity; //передавать будем Универ,добавляем класс,ибегаем import в h.

@interface AGCoursesViewController : AGCoreDataViewController

@property (strong, nonatomic) AGUniversity *university; //сохр контроллер

@end
