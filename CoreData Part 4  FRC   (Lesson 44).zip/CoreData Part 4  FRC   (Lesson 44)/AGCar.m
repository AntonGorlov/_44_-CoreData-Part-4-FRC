//
//  AGCar.m
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGCar.h"
#import "AGStudent.h"

@implementation AGCar

// Insert code here to add functionality to your managed object subclass

@end
