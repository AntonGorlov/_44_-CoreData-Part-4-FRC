//
//  AGCourse+CoreDataProperties.m
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGCourse+CoreDataProperties.h"

@implementation AGCourse (CoreDataProperties)

@dynamic name;
@dynamic students;
@dynamic university;

@end
