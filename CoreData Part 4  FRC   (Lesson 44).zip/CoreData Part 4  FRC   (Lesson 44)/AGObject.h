//
//  AGObject.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface AGObject : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "AGObject+CoreDataProperties.h"
