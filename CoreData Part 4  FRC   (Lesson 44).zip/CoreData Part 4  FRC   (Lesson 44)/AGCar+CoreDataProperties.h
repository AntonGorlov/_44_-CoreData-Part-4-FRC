//
//  AGCar+CoreDataProperties.h
//  CoreData Part 4  FRC   (Lesson 44)
//
//  Created by Anton Gorlov on 31.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGCar.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGCar (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *model;
@property (nullable, nonatomic, retain) AGStudent *owner;

@end

NS_ASSUME_NONNULL_END
